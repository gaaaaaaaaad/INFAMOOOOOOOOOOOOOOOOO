import pyperclip
import time

# The text to be added to any copied content
footer_text = "\n-# This user is an Infamoose ENGInneer. [Learn More](<https://www.infamousunleashed.org/>)"

# Store the last copied content to detect changes
last_copied_text = pyperclip.paste()

while True:
    # Get the current clipboard content
    current_copied_text = pyperclip.paste()

    # If the clipboard content has changed
    if current_copied_text != last_copied_text:
        # Add the footer text only if it hasn't been added already
        if footer_text not in current_copied_text:
            # Update the clipboard content with the appended footer text
            modified_text = current_copied_text + footer_text
            pyperclip.copy(modified_text)
            print(f"Modified clipboard content:\n{modified_text}")  # Optional: Print the modified content
            last_copied_text = modified_text
        else:
            last_copied_text = current_copied_text

    # Check every 0.5 seconds
    time.sleep(0.5)

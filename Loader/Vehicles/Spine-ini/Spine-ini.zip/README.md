# INI-formatted-object-vehicle-spawns
.INI formatted object vehicle spawns

Backup of all: http://nigger.menu/Vehicles/Spinethetic/
